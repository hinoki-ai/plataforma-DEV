import ChatWidget from "@/vercel/components/ChatWidget"
import { Button } from "@/components/ui/button"
import { NotificationBadge, withNotification } from "@/components/ui/notification-badge"
import { Bell, Mail, Settings } from "lucide-react"

const ButtonWithBadge = withNotification(Button)

export default function Home() {
  return (
    <main className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4 gap-12">
      <div className="w-full max-w-4xl grid md:grid-cols-2 gap-8 items-center">
        <div className="space-y-4">
          <h1 className="text-4xl font-bold tracking-tight text-slate-900">Educational Management Platform</h1>
          <p className="text-lg text-slate-600">
            Welcome to the admin dashboard. Use the AI Assistant on the right to answer questions about the platform
            without risking any data changes.
          </p>
          <div className="p-4 bg-white rounded-lg border shadow-sm">
            <h3 className="font-semibold mb-2">Try asking:</h3>
            <ul className="list-disc list-inside space-y-1 text-slate-600">
              <li>How do I add a new student?</li>
              <li>Where can I find the grade reports?</li>
              <li>Why is the attendance button disabled?</li>
            </ul>
          </div>
        </div>

        <div className="flex justify-center">
          <ChatWidget />
        </div>
      </div>

      <div className="w-full max-w-4xl border-t pt-12">
        <h2 className="text-2xl font-bold mb-8 text-center">Notification Badge Feature Demo</h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Manual Composition */}
          <div className="bg-white p-6 rounded-xl shadow-sm border space-y-6">
            <h3 className="text-lg font-semibold">Manual Composition</h3>
            <div className="flex flex-wrap gap-6 items-center justify-center">
              <div className="relative">
                <Button variant="outline" size="icon">
                  <Bell className="h-4 w-4" />
                </Button>
                <NotificationBadge />
              </div>
              <div className="relative">
                <Button>Publish Changes</Button>
                <NotificationBadge />
              </div>
            </div>
          </div>

          {/* Higher Order Component */}
          <div className="bg-white p-6 rounded-xl shadow-sm border space-y-6">
            <h3 className="text-lg font-semibold">Higher Order Component</h3>
            <div className="flex flex-wrap gap-6 items-center justify-center">
              <ButtonWithBadge showBadge>
                <Mail className="mr-2 h-4 w-4" /> Inbox
              </ButtonWithBadge>
              <ButtonWithBadge showBadge variant="secondary">
                <Settings className="mr-2 h-4 w-4" /> Settings
              </ButtonWithBadge>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
