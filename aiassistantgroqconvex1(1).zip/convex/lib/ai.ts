import OpenAI from "openai"
import type { ActionCtx } from "../_generated/server"

// Initialize OpenAI client (Required for Embeddings, Optional for Chat)
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

// Initialize Groq client (Optional, best for fast Chat)
const groq = process.env.GROQ_API_KEY
  ? new OpenAI({
      apiKey: process.env.GROQ_API_KEY,
      baseURL: "https://api.groq.com/openai/v1",
    })
  : null

export const embed = async (ctx: ActionCtx, model: string, text: string) => {
  if (!process.env.OPENAI_API_KEY) {
    throw new Error("OPENAI_API_KEY is missing. It is required for search functionality.")
  }

  const response = await openai.embeddings.create({
    model: model || "text-embedding-3-large",
    input: text,
  })
  return response.data[0].embedding
}

export const ai = {
  chat: async (ctx: ActionCtx, model: string | undefined, args: { messages: any[]; max_tokens?: number }) => {
    let client = openai
    let selectedModel = model || "gpt-4o-mini" // Default fallback

    // If Groq is available, use it for speed (unless a specific OpenAI model was requested)
    if (groq && (!model || model.startsWith("llama") || model.startsWith("mixtral"))) {
      client = groq
      selectedModel = model || "llama3-8b-8192"
    } else if (!process.env.OPENAI_API_KEY) {
      // If neither is available, return a mock response to prevent crash
      console.warn("No API keys set for AI. Returning mock response.")
      return {
        text: "Please configure OPENAI_API_KEY or GROQ_API_KEY in your Convex dashboard to enable AI responses.",
      }
    }

    const response = await client.chat.completions.create({
      model: selectedModel,
      messages: args.messages,
      max_tokens: args.max_tokens || 512,
    })

    return {
      text: response.choices[0].message.content || "",
    }
  },
}
